#!/bin/bash

zip -r lambda.zip index.js config.json node_modules/async node_modules/gm
